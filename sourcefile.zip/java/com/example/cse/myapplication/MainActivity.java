package com.example.cse.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import com.example.cse.myapplication.AlarmBox.Alarm;


public class MainActivity extends AppCompatActivity {


    public ImageButton plusDrug;
    public ImageButton alarmDrug;
    public ImageButton hospitalfind;
    public ImageButton manbo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        plusDrug = (ImageButton) findViewById(R.id.drugPlus);
        alarmDrug = (ImageButton) findViewById(R.id.drugAlarm);
        hospitalfind=(ImageButton) findViewById(R.id.findHospital);
        manbo=(ImageButton) findViewById(R.id.manbo);


        plusDrug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goPlus = new Intent(MainActivity.this, PharmacySearch.class);
                startActivity(goPlus);
            }
        });

        alarmDrug.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goAlarm = new Intent(MainActivity.this, Alarm.class);
                startActivity(goAlarm);
            }
        });

        hospitalfind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goHospital = new Intent(MainActivity.this, Hospital.class);
                startActivity(goHospital);
            }
        });

        manbo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gomanbo = new Intent(MainActivity.this, Manbo.class);
                startActivity(gomanbo);
            }
        });

    }
}
