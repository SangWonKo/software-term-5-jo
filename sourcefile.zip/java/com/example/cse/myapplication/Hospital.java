package com.example.cse.myapplication;

import android.os.Bundle;

import android.app.Activity;

import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.io.InputStreamReader;

import java.net.URL;
import java.net.URLEncoder;

public class Hospital extends Activity {

    EditText edit;
    TextView text;

    String key="1GyjhUJoRN2nz860pgSQaOycZbHUKsh5cL64ffOjy5heL8vcq3a9cVlgt9sliB%2Faedm%2FLNMZpA1Zwj2t3Mbd5Q%3D%3D";

    String data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hospital);

        edit= (EditText)findViewById(R.id.edit);
        text= (TextView)findViewById(R.id.text);
    }


    public void mOnClick(View v){

        switch( v.getId() ){
            case R.id.button:
                new Thread(new Runnable() {

                    @Override
                    public void run() {
                        data=getXmlData();



                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {

                                text.setText(data);
                            }
                        });
                    }
                }).start();
                break;
        }

    }

    String getXmlData()  {

        StringBuffer buffer=new StringBuffer();

        String str= edit.getText().toString();
        String location = URLEncoder.encode(str);   //지역 검색 위한 변수

        String queryUrl="http://apis.data.go.kr/B551182/hospInfoService/getHospBasisList?"//요청 URL
                +"emdongNm=&yadmNm="+location
                +"&pageNo=1&numOfRows=1000&ServiceKey=" + key;

        try {
            URL url= new URL(queryUrl);
            InputStream is= url.openStream();

            XmlPullParserFactory factory= XmlPullParserFactory.newInstance();
            XmlPullParser xpp= factory.newPullParser();
            xpp.setInput( new InputStreamReader(is, "UTF-8") );

            String tag;

            xpp.next();
            int eventType= xpp.getEventType();

            while( eventType != XmlPullParser.END_DOCUMENT ){
                switch( eventType ){
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;

                    case XmlPullParser.START_TAG:
                        tag= xpp.getName();

                        if(tag.equals("item")) ;
                        else if(tag.equals("addr")){
                            buffer.append("주소 : ");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }

                        else if(tag.equals("distance")){
                            buffer.append("거리 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }

                        else if(tag.equals("estbDd")){
                            buffer.append("개설일자 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }

                        else if(tag.equals("hospUrl")){
                            buffer.append("홈페이지 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }

                        else if(tag.equals("postNo")){
                            buffer.append("우편번호 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }

                        else if(tag.equals("sgguCdNm")){
                            buffer.append("시군구명 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }

                        else if(tag.equals("sidoCdNm")){
                            buffer.append("시도명 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }
                        else if(tag.equals("telno")){
                            buffer.append("전화번호 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }
                        else if(tag.equals("XPos")){
                            buffer.append("위도 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }
                        else if(tag.equals("YPos")){
                            buffer.append("경도 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }
                        else if(tag.equals("yadmNm")){
                            buffer.append("병원명 :");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }

                        break;

                    case XmlPullParser.TEXT:
                        break;

                    case XmlPullParser.END_TAG:
                        tag= xpp.getName();

                        if(tag.equals("item")) buffer.append("\n");

                        break;
                }

                eventType= xpp.next();
            }

        } catch (Exception e) {
            // TODO Auto-generated catch blocke.printStackTrace();
        }

        buffer.append("파싱 끝\n");

        return buffer.toString();

    }

}