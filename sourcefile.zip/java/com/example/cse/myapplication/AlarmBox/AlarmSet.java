package com.example.cse.myapplication.AlarmBox;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.cse.myapplication.R;

import java.util.Calendar;

public class AlarmSet extends AppCompatActivity {

    public Button btnMake;
    public Button btnSet;
    public EditText alarmTag;

    CheckBox checkSun, checkMon, checkTue, checkWed, checkThu, checkFri, checkSat;
    Switch isRepeat;
    int myHour, myMinute;
    AlarmManager mAlarmManager;

    AlarmDBHelper mDbOpenHelper;

    AlarmDBHelper helper;
    SQLiteDatabase db;

 /*   AlarmDbmanager dbManager;
    SQLiteDatabase db;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_alarm);

        btnMake=(Button)findViewById(R.id.doMake);
        btnSet=(Button)findViewById(R.id.doSet);
        alarmTag=(EditText)findViewById(R.id.nameA);


        mAlarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        checkSun=(CheckBox)findViewById(R. id. setSun);
        checkMon=(CheckBox)findViewById(R. id. setMon);
        checkTue=(CheckBox)findViewById(R. id. setTue);
        checkWed=(CheckBox)findViewById(R. id. setWed);
        checkThu=(CheckBox)findViewById(R. id. setThu);
        checkFri=(CheckBox)findViewById(R. id. setFri);
        checkSat=(CheckBox)findViewById(R. id. setSat);
        isRepeat=(Switch)findViewById(R. id. addSwitch);

        final int index=0;
        helper=new AlarmDBHelper(this);

        try {
            db=helper.getWritableDatabase();
        } catch (SQLiteException e) {
            db=helper.getReadableDatabase();
        }

        mDbOpenHelper=new AlarmDBHelper(this);

        btnMake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // cancelAlarm();
                String tag=alarmTag.getText().toString();
                boolean[] week = { false, checkSun.isChecked(), checkMon.isChecked(), checkTue.isChecked(),
                checkWed.isChecked(), checkThu.isChecked(), checkFri.isChecked(), checkSat.isChecked()};

                boolean isRep = isRepeat.isChecked();
                int len = week.length;
                for (int i = 0; i < len; i++)
                {
                    if (week[i])
                    {
                        isRep = true;
                        break;
                    }
                }

                // 알람 등록
                Intent intent = new Intent(AlarmSet.this, AlarmReceiver.class);

                long triggerTime = 0;
                long intervalTime = 24 * 60 * 60 * 1000;// 24시간
                if(isRep)
                {
                    String repeat="반복 알람";
                    intent.putExtra("one_time", false);
                    intent.putExtra("day_of_week", week);
                    intent.putExtra("tag", tag);
                    PendingIntent pending = getPendingIntent(intent);
                    pending=PendingIntent.getBroadcast(AlarmSet.this, 0, intent, 0); //반복 알람은 인덱스 0
                                                                                    //반복 알람을 추가하면 이전 알람은 자동 삭제(오버라이팅)된다

                    triggerTime = setTriggerTime();

                    mAlarmManager.setRepeating(AlarmManager.RTC_WAKEUP, triggerTime, intervalTime, pending);

                    //알람 디비에 설정한 거 저장..ㅇ0ㅇ
                    String store=myHour+" 시 "+myMinute+" 분";
                    db.execSQL("INSERT INTO contact VALUES(null, '"+store+"','"+repeat+"','"+tag+"');" );

                    Toast.makeText(AlarmSet.this, "반복 알람이 설정(갱신)되었습니다!", Toast.LENGTH_LONG).show();

                    finish();
                }
                else
                {
                    String repeat="반복 없음";
                    intent.putExtra("one_time", true);
                    intent.putExtra("tag", tag);
                    PendingIntent pending = getPendingIntent(intent);
                    triggerTime = setTriggerTime();
                    mAlarmManager.set(AlarmManager.RTC_WAKEUP, triggerTime, pending);
                  //  dbManager.insert("insert into ALARM_LIST values(null, '" + myHour + "', " + myMinute + repeat + ");");
                    //알람 디비에 설정한 거 저장..ㅇ0ㅇ
                    String store=myHour+" 시 "+myMinute+" 분";
                    db.execSQL("INSERT INTO contact VALUES(null, '"+store+"','"+repeat+"','"+tag+"');" );
                    Toast.makeText(AlarmSet.this, "한 번만 울리는 알람이 설정(갱신)되었습니다!", Toast.LENGTH_LONG).show();

                }
                finish();
            }
        });

        btnSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Dialog dlgTime = new TimePickerDialog(AlarmSet.this, myTimeSetListener, myHour,
                        myMinute, false);
                dlgTime.show();
            }
        });

        //
    }
    private TimePickerDialog.OnTimeSetListener myTimeSetListener
            = new TimePickerDialog.OnTimeSetListener() {

        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            myHour=hourOfDay;
            myMinute=minute;
            String time =  String.valueOf(hourOfDay) + "시 "
                    + String.valueOf(minute)+"분에\n알람이 설정됩니다.";
            Toast.makeText(AlarmSet.this, time, Toast.LENGTH_LONG).show();
        }
    };

    private PendingIntent getPendingIntent(Intent intent)
    {
        PendingIntent pIntent = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        return pIntent;
    }


    private long setTriggerTime()
    {
        // current Time
        long atime = System.currentTimeMillis();
        // timepicker
        Calendar curTime = Calendar.getInstance();
        curTime.set(Calendar.HOUR_OF_DAY, myHour);
        curTime.set(Calendar.MINUTE,myMinute);
        curTime.set(Calendar.SECOND, 0);
        curTime.set(Calendar.MILLISECOND, 0);
        long btime = curTime.getTimeInMillis();
        long triggerTime = btime;
        if (atime > btime)
            triggerTime += 1000 * 60 * 60 * 24;

        return triggerTime;
    }

    private void cancelAlarm()
    {
        Intent intent = new Intent(this, AlarmReceiver.class);
        PendingIntent pending = getPendingIntent(intent);
        this.mAlarmManager.cancel(pending);
    }

}


